document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form submission
  
    // Redirect to Google
    window.location.href = "file:///F:/Git/Final%20Year%20Project/covid-phases.html";
  });
  